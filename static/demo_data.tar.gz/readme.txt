This archive contains files storing isoform stack data and heatmap data that match with the demo data visualization on IsoVis.

The descriptions of the files are as follows:
demo_data.gtf: A GTF stack file containing data representing the 'User isoforms' in the isoform stack of the demo data visualization.
demo_data.bed12: A BED12 stack file containing data representing the 'User isoforms' in the isoform stack of the demo data visualization.
demo_data.bed6: A BED6 stack file containing data representing the 'User isoforms' in the isoform stack of the demo data visualization.
demo_data.csv: A CSV file containing heatmap data related to the isoform stack data.