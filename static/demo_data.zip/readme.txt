This archive contains files storing isoform stack data and heatmap data that match the demo data visualization on IsoVis.

The descriptions of the files are as follows:
demo_data.gff3: A GFF3 stack file containing data representing the 'User isoforms' in the isoform stack of the demo data visualization. It also contains user open reading frames (ORFs) for both known and novel transcripts.
demo_data.gtf: A GTF stack file containing data representing the 'User isoforms' in the isoform stack of the demo data visualization. It contains user ORFs for the transcripts.
demo_data.bed12: A BED12 stack file containing data representing the 'User isoforms' in the isoform stack of the demo data visualization. It contains user ORfs for the transcripts.
demo_data.bed6: A BED6 stack file containing data representing the 'User isoforms' in the isoform stack of the demo data visualization. It does not contain any user ORFs.
demo_data.csv: A CSV file containing heatmap data related to the isoform stack data.